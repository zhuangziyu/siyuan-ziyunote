# 思源笔记看视频做笔记插件

> 需要配合子魚笔记软件使用

官网：http://vnote.littlefly.fun/
